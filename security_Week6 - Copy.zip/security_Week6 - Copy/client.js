const io = require('socket.io-client');
const readline = require('readline');
const crypto = require('crypto');

let username = ''; // To store the username

// Connect to the server
const socket = io('http://localhost:3000');

// Create interface to read input from console
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to hash message
function hashMessage(message) {
    return crypto.createHash('sha256').update(message).digest('hex');
}

// Show a message when the client connects to the server
socket.on('connect', () => {
    console.clear();  // Clears the console for a cleaner look
    console.log('Connected to the server');
    // Prompt user for their username
    rl.question('Enter your username: ', (input) => {
        username = input;  // Store the username
        console.log(`Welcome, ${username}! You can start chatting.`);
        rl.setPrompt('> ');  // Set the prompt symbol
        rl.prompt();  // Show the prompt for sending messages
    });
});

// Handle message input and sending
rl.on('line', (input) => {
    if (username === '') {
        console.log('Please enter your username first.');
    } else {
        const hash = hashMessage(input);
        socket.emit('chat', { username: username, message: input, hash }); // Emit 'chat' event
    }
    rl.prompt();  // Show the prompt again after sending the message
});

// Handle incoming messages from the server
socket.on('chat', (data) => {  // Listen for 'chat' event
    let { username, message } = data;  // Correct variable name
    console.log(`${username}: ${message}`);  // Log received message without prefix
    rl.prompt();  // Show the prompt again after receiving the message
});

// Handle Ctrl+C (SIGINT) to display "Exiting..." before closing the program
process.on('SIGINT', () => {
    console.log('\nExiting...');
    socket.disconnect();  // Disconnect from the server
    rl.close();  // Close readline interface
    process.exit();  // Exit the process
});

// Handle the server disconnecting on its own (server-side disconnect)
socket.on('disconnect', () => {
    console.log('\nServer has disconnected');
    rl.prompt();  // Still keep prompt if the server disconnects unexpectedly
});
