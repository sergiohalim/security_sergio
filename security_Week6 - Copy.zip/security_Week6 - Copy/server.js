const http = require('http');
const socketIo = require('socket.io');

// Create a basic HTTP server
const server = http.createServer();
const io = socketIo(server);

io.on('connection', (socket) => {
    console.log('Client connected');

    // Listen for chat messages from clients
    socket.on('chat', (data) => {  // Listen for 'chat' event
        let { username, message } = data;  // Correct variable name
        console.log(`Received message from ${username}: ${message}`);  // Log received message
        
        // Append a note indicating the message was modified by the server
        const modifiedMessage = `${message} (modified by server)`;

        // Broadcast the modified message to other clients
        socket.broadcast.emit('chat', {
            username,
            message: modifiedMessage,
        });
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

// Start the server on port 3000
server.listen(3000, () => {
    console.log('Server listening on port 3000');
});
